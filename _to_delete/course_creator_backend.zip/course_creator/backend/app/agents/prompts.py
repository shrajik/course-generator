"""Prompt construction.

All prompts are plain functions so they can be unit tested and diffed. Keeping
them here (rather than inline) also makes it obvious that the two templates share
one pipeline: the template configuration is *data* inside the prompt, not a
separate code path.

Convention: prompts include machine-readable markers (`COURSE TITLE:`,
`CHAPTER TITLE:`, `TEMPLATE KIND:`) which the offline mock client uses to produce
context-appropriate placeholder content.
"""

from __future__ import annotations

from app.schemas.blueprint import BlueprintChapter, CourseBlueprint
from app.schemas.course import CourseInput, ImproveTocRequest
from app.schemas.document import Block
from app.schemas.research import ChapterResearch
from app.schemas.template import CourseTemplate

GLOBAL_RULES = """\
Hard rules that override anything else:
- Never invent facts, statistics, quotes, sources, APIs or product behaviour. If
  the research does not support a claim, either omit it or write it as a general
  statement without a fabricated number.
- Respect the Do's and Don'ts exactly. A Don't is a prohibition, not a preference.
- Write for the stated target audience, at their level, in their vocabulary.
- Output valid JSON only, matching the requested schema. No prose outside the JSON.
"""


def _bullets(items: list[str], empty: str = "(none provided)") -> str:
    return "\n".join(f"- {item}" for item in items if item) or empty


def _numbered(items: list[str]) -> str:
    return "\n".join(f"{i}. {item}" for i, item in enumerate(items, start=1)) or "(empty)"


def _course_context(course_input: CourseInput, template: CourseTemplate) -> str:
    toc_lines = []
    for index, item in enumerate(course_input.toc, start=1):
        toc_lines.append(f"{index}. {item.title}")
        for section in item.sections:
            toc_lines.append(f"   - {section}")
        if item.notes:
            toc_lines.append(f"   (note: {item.notes})")
    return f"""\
COURSE TITLE: {course_input.course_title}
TARGET AUDIENCE: {course_input.target_audience}
TEMPLATE KIND: {template.kind}
TEMPLATE: {template.name} ({template.template_id}) - {template.description}
LANGUAGE: {course_input.language}
REQUESTED TONE: {course_input.tone or "(not specified)"}

TABLE OF CONTENTS (as provided by the user):
{chr(10).join(toc_lines)}

DO'S:
{_bullets(course_input.dos)}

DON'TS:
{_bullets(course_input.donts)}
"""


# ---------------------------------------------------------------------------
# planner
# ---------------------------------------------------------------------------

PLANNER_SYSTEM = f"""\
You are a senior instructional designer building a course blueprint.

{GLOBAL_RULES}

Additional rules for planning:
- Keep the user's chapter titles and their order. Report problems in `critique`
  instead of silently rewriting the table of contents.
- Give every chapter a stable id of the form `chapter_1`, `chapter_2`, ... in the
  order the user supplied, and set `order` to the same number.
- `required_blocks` / `optional_blocks` must use only the block types listed for
  the selected template.
- Research questions should be specific enough to search for.
"""


def planner_user(course_input: CourseInput, template: CourseTemplate) -> str:
    return f"""\
{_course_context(course_input, template)}

TEMPLATE CHAPTER STRUCTURE (each chapter should be able to satisfy this):
{template.outline_for_prompt()}

ALLOWED BLOCK TYPES: {", ".join(bt.value for bt in template.allowed_block_types)}
TEMPLATE WRITING GUIDANCE: {template.writer_guidance}

Produce the course blueprint:
1. A one-paragraph course summary.
2. Course-level learning objectives and prerequisites.
3. One entry per chapter in the table of contents above, in the same order, with
   sections, key concepts, required/optional blocks and research questions.
4. A critique listing missing concepts, duplicate topics, ordering problems and
   notes on the learning progression. Put any table-of-contents changes you would
   recommend in `critique.suggested_toc` - do not apply them to `chapters`.
"""


# ---------------------------------------------------------------------------
# TOC improvement
# ---------------------------------------------------------------------------

TOC_SYSTEM = f"""\
You are a senior curriculum reviewer improving a course table of contents.

{GLOBAL_RULES}

Rules:
- Return the full proposed table of contents in `suggested_toc`, including
  chapters you kept unchanged, in the order you recommend.
- Every difference from the original must appear in `changes` with an action of
  add, remove, rename, reorder, split or merge, plus a concrete reason.
- Be conservative: propose changes that measurably improve learning progression,
  not cosmetic rewording.
"""


def toc_user(request: ImproveTocRequest, template: CourseTemplate) -> str:
    return f"""\
COURSE TITLE: {request.course_title}
TARGET AUDIENCE: {request.audience or "(not specified)"}
TEMPLATE KIND: {template.kind}
TEMPLATE: {template.name} - {template.description}

CURRENT TABLE OF CONTENTS:
{_numbered([item.title for item in request.toc])}

DO'S:
{_bullets(request.dos)}

DON'TS:
{_bullets(request.donts)}

Review the table of contents for: missing foundational concepts, duplicate or
overlapping chapters, poor ordering, and gaps in the learning progression.
Then return the improved table of contents, the list of changes and your reasoning.
"""


# ---------------------------------------------------------------------------
# research
# ---------------------------------------------------------------------------

RESEARCH_SYSTEM = """\
You are a meticulous research assistant preparing source material for one chapter
of a course. Gather accurate, current, specific material. Prefer authoritative
primary sources. Never fabricate a source, a statistic or a quote - if you cannot
verify something, leave it out and say so. Note the URL of anything you rely on.
"""


def research_user(
    blueprint: CourseBlueprint,
    chapter: BlueprintChapter,
    template: CourseTemplate,
    *,
    course_input: CourseInput,
) -> str:
    return f"""\
COURSE TITLE: {blueprint.course_title}
CHAPTER TITLE: {chapter.title}
TEMPLATE KIND: {template.kind}
TARGET AUDIENCE: {blueprint.audience or course_input.target_audience}

CHAPTER OBJECTIVE: {chapter.objective}
KEY CONCEPTS: {", ".join(chapter.key_concepts) or "(none listed)"}
CHAPTER SECTIONS:
{_bullets([s.title for s in chapter.sections])}

RESEARCH QUESTIONS TO ANSWER:
{_numbered(chapter.research_questions or [f"What must a learner know about {chapter.title}?"])}

DO'S:
{_bullets(course_input.dos)}

DON'TS:
{_bullets(course_input.donts)}

TEMPLATE RESEARCH GUIDANCE: {template.research_guidance}

Research THIS CHAPTER ONLY. Collect: definitions, core concepts, examples,
real-world examples, case studies, important facts, statistics (only with a
source), common mistakes, best practices, references with URLs, FAQs, visual
opportunities, exercise ideas and quiz ideas.
"""


RESEARCH_STRUCTURE_SYSTEM = f"""\
You convert research notes into a structured research artifact.

{GLOBAL_RULES}

Rules:
- Use only what is present in the notes. Do not add new facts.
- Copy source URLs exactly as they appear in the notes. Never guess a URL.
- Leave a list empty rather than padding it with generic filler.
"""


def research_structure_user(chapter_title: str, notes: str, template: CourseTemplate) -> str:
    return f"""\
CHAPTER TITLE: {chapter_title}
TEMPLATE KIND: {template.kind}

RESEARCH NOTES:
---
{notes}
---

Convert these notes into the structured research artifact.
"""


# ---------------------------------------------------------------------------
# writer
# ---------------------------------------------------------------------------

WRITER_SYSTEM = f"""\
You are an expert course author writing ONE chapter of a course.

{GLOBAL_RULES}

How to produce blocks:
- Return an ordered list of blocks. The first block must be a `heading` (level 1)
  containing the chapter title.
- Use only the allowed block types. Set `section_key` on every block to the
  template section it belongs to.
- Include every REQUIRED template section. Include optional sections only when
  they genuinely help this specific chapter - do not force every block type into
  every chapter.
- Fill only the fields that a block type needs; leave the rest empty.
- Paragraphs: 60-140 words each. Several short paragraphs beat one long one.
- For an `image` block, do not produce the image. Provide `image_purpose`, a
  precise `image_prompt` (style, composition, labels) and a `caption`.
- For `code` blocks set `language` and keep the sample runnable and idiomatic.
- For `quiz` blocks give 3-5 questions, each with the answer and an explanation.
- Vary the formats: stories, analogies, examples, case studies, tips, warnings,
  did-you-know callouts, light and appropriate humour, exercises, challenges,
  quizzes and reflection questions - whichever suit the topic and audience.
- End with a `summary` block of key takeaways.
- Finish by writing a compact `chapter_summary` (3-5 sentences) that a later
  chapter can use as context. Never reference material the reader has not met yet.
"""


def writer_user(
    blueprint: CourseBlueprint,
    chapter: BlueprintChapter,
    template: CourseTemplate,
    research: ChapterResearch | None,
    previous_summaries: list[tuple[str, str]],
    *,
    course_input: CourseInput,
    revision_notes: str = "",
) -> str:
    previous = (
        "\n".join(f"- {title}: {summary}" for title, summary in previous_summaries)
        or "(this is the first chapter)"
    )
    research_text = research.compact_context() if research else "(no research available)"
    revision = (
        f"\nREVISION REQUIRED - the reviewer raised these points, fix all of them:\n{revision_notes}\n"
        if revision_notes
        else ""
    )
    return f"""\
{_course_context(course_input, template)}

COURSE SUMMARY: {blueprint.course_summary}
COURSE LEARNING OBJECTIVES:
{_bullets(blueprint.learning_objectives)}

CHAPTER TITLE: {chapter.title}
CHAPTER NUMBER: {chapter.order}
CHAPTER OBJECTIVE: {chapter.objective}
CHAPTER SECTIONS:
{_bullets([f"{s.title}: {s.summary}" for s in chapter.sections])}
KEY CONCEPTS: {", ".join(chapter.key_concepts) or "(none listed)"}
TARGET LENGTH: about {chapter.estimated_words or 1400} words

PREVIOUS CHAPTER SUMMARIES (for continuity - do not repeat their content):
{previous}

TEMPLATE SECTIONS TO FOLLOW:
{template.outline_for_prompt()}

ALLOWED BLOCK TYPES: {", ".join(bt.value for bt in template.allowed_block_types)}
BLOCK TYPES THAT MUST APPEAR: {", ".join(bt.value for bt in template.required_block_types)}
TEMPLATE WRITING GUIDANCE: {template.writer_guidance}
IMAGE STYLE GUIDANCE: {template.image_guidance}

CHAPTER RESEARCH (your only source of facts):
---
{research_text}
---
{revision}
Write this chapter now.
"""


# ---------------------------------------------------------------------------
# reviewer
# ---------------------------------------------------------------------------

REVIEWER_SYSTEM = f"""\
You are a strict but fair course reviewer. One reviewer serves both templates.

{GLOBAL_RULES}

Score each dimension from 0 to 10. Review:
accuracy, clarity, structure, audience suitability, repetition, adherence to the
Do's, absence of the Don'ts, presence of the required template blocks, and
logical flow.

Set `technical_correctness` for technical courses (also judging code quality) and
`practical_relevance` for non-technical courses. Leave the other one null.

Set `approved` to false only when something must change before publication.
Report every problem as an issue with a severity of blocker, major or minor, the
index of the offending block, and a concrete suggested fix. Do not rewrite the
chapter yourself.
"""


def reviewer_user(
    blueprint: CourseBlueprint,
    chapter: BlueprintChapter,
    template: CourseTemplate,
    blocks: list[dict],
    *,
    course_input: CourseInput,
    previous_summaries: list[tuple[str, str]],
) -> str:
    import json

    previous = (
        "\n".join(f"- {title}: {summary}" for title, summary in previous_summaries)
        or "(this is the first chapter)"
    )
    return f"""\
COURSE TITLE: {blueprint.course_title}
CHAPTER TITLE: {chapter.title}
TEMPLATE KIND: {template.kind}
TARGET AUDIENCE: {course_input.target_audience}

DO'S:
{_bullets(course_input.dos)}

DON'TS:
{_bullets(course_input.donts)}

REQUIRED TEMPLATE SECTIONS: {", ".join(s.key for s in template.required_sections())}
BLOCK TYPES THAT MUST APPEAR: {", ".join(bt.value for bt in template.required_block_types)}
TEMPLATE REVIEW FOCUS:
{_bullets(template.review_focus)}

PREVIOUS CHAPTER SUMMARIES (check for repetition against these):
{previous}

CHAPTER BLOCKS (index: type -> content):
{json.dumps([{"index": i, "type": b.get("type"), "content": b.get("content")} for i, b in enumerate(blocks)], ensure_ascii=False)[:60000]}

Review this chapter now.
"""


# ---------------------------------------------------------------------------
# editor
# ---------------------------------------------------------------------------

EDITOR_SYSTEM = f"""\
You are the AI editor behind a visual course editor. The user selects one or more
blocks and gives an instruction. You return a PATCH - never a whole document.

{GLOBAL_RULES}

Rules:
- Emit the smallest set of operations that satisfies the instruction.
- Allowed operations: update_block, delete_block, insert_block, replace_block,
  replace_image, update_style.
- Only touch the selected blocks, plus blocks you insert next to them.
- `update_block.content` is merged into the existing content, so send only the
  keys that change. Keep the block's type unless the instruction requires a
  different one (then use replace_block).
- For a new image use replace_image (existing image block) or insert_block with an
  `image` block carrying `purpose`, `prompt` and `caption`. Never output image data.
- update_style may only set presentation keys: font_size, font_weight, color,
  background, align, italic, padding, border_radius, border_color, line_height.
- Never invent a block_id. Use only ids that appear in the context below.
- Explain what you changed in `reasoning`.
"""


def editor_user(
    document_title: str,
    template: CourseTemplate,
    selected: list[Block],
    context_blocks: list[Block],
    instruction: str,
    *,
    audience: str = "",
) -> str:
    import json

    def describe(block: Block) -> dict:
        return {
            "block_id": block.id,
            "type": block.type.value,
            "page": block.meta.chapter_number,
            "content": block.content,
            "style": block.style.model_dump(exclude_none=True),
        }

    return f"""\
COURSE TITLE: {document_title}
TEMPLATE KIND: {template.kind}
TARGET AUDIENCE: {audience or "(not specified)"}
ALLOWED BLOCK TYPES: {", ".join(bt.value for bt in template.allowed_block_types)}

USER INSTRUCTION:
{instruction}

SELECTED BLOCKS (these are what you may modify):
{json.dumps([describe(b) for b in selected], ensure_ascii=False)[:40000]}

SURROUNDING BLOCKS (read-only context):
{json.dumps([{"block_id": b.id, "type": b.type.value, "preview": b.text_preview(160)} for b in context_blocks], ensure_ascii=False)[:20000]}

Return the patch.
"""
