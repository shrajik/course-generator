"""Phase 3 - Chapter Writer.

One chapter per model call. Context is deliberately bounded: blueprint, audience,
do's/don'ts, template, chapter outline, chapter research and *summaries* of the
previous chapters (never their full text).
"""

from __future__ import annotations

from app.agents import prompts
from app.core.config import Settings, get_settings
from app.core.ids import utc_now_iso
from app.core.logging import get_logger
from app.course.blocks.normalizer import normalize_draft_blocks
from app.schemas.blocks import BlockType
from app.schemas.blueprint import BlueprintChapter, CourseBlueprint
from app.schemas.course import CourseInput
from app.schemas.document import Block
from app.schemas.draft import ChapterDraft, DraftBlock, GeneratedChapter
from app.schemas.research import ChapterResearch
from app.schemas.review import ChapterReview
from app.schemas.template import CourseTemplate
from app.services.openai_service import AIClient, get_ai_client

log = get_logger(__name__)


class WriterAgent:
    def __init__(self, ai: AIClient | None = None, settings: Settings | None = None) -> None:
        self.ai = ai or get_ai_client()
        self.settings = settings or get_settings()

    async def write_chapter(
        self,
        *,
        blueprint: CourseBlueprint,
        chapter: BlueprintChapter,
        template: CourseTemplate,
        course_input: CourseInput,
        research: ChapterResearch | None,
        previous_summaries: list[tuple[str, str]],
        revision_notes: str = "",
    ) -> tuple[list[Block], str]:
        """Returns (validated blocks, compact chapter summary)."""
        draft = await self.ai.structured(
            schema=ChapterDraft,
            system=prompts.WRITER_SYSTEM,
            user=prompts.writer_user(
                blueprint,
                chapter,
                template,
                research,
                previous_summaries,
                course_input=course_input,
                revision_notes=revision_notes,
            ),
            model=self.settings.writer_model,
            purpose=f"writer:{chapter.id}",
        )

        drafts = self._ensure_title_heading(draft.blocks, chapter.title)
        blocks = normalize_draft_blocks(
            drafts,
            template=template,
            chapter_id=chapter.id,
            chapter_number=chapter.order,
        )
        if not blocks:
            raise ValueError(f"Writer produced no usable blocks for {chapter.id}")

        summary = draft.chapter_summary or self._fallback_summary(chapter, blocks)
        log.info("Wrote %s: %s blocks", chapter.id, len(blocks))
        return blocks, summary

    async def revise_chapter(
        self,
        *,
        blueprint: CourseBlueprint,
        chapter: BlueprintChapter,
        template: CourseTemplate,
        course_input: CourseInput,
        research: ChapterResearch | None,
        previous_summaries: list[tuple[str, str]],
        review: ChapterReview,
    ) -> tuple[list[Block], str]:
        return await self.write_chapter(
            blueprint=blueprint,
            chapter=chapter,
            template=template,
            course_input=course_input,
            research=research,
            previous_summaries=previous_summaries,
            revision_notes=self.review_to_notes(review),
        )

    # --- helpers ----------------------------------------------------------
    @staticmethod
    def review_to_notes(review: ChapterReview) -> str:
        lines: list[str] = []
        for issue in review.issues:
            if issue.severity in {"blocker", "major"}:
                lines.append(
                    f"[{issue.severity}/{issue.category}] block {issue.block_index}: "
                    f"{issue.description} -> {issue.suggestion}"
                )
        for missing in review.missing_required_blocks:
            lines.append(f"[blocker/template] missing required block or section: {missing}")
        for violation in review.donts_violations:
            lines.append(f"[blocker/donts] violates a Don't: {violation}")
        for violation in review.dos_violations:
            lines.append(f"[major/dos] does not honour a Do: {violation}")
        for note in review.repetition_notes:
            lines.append(f"[major/repetition] {note}")
        return "\n".join(lines) or review.summary

    @staticmethod
    def _ensure_title_heading(drafts: list[DraftBlock], title: str) -> list[DraftBlock]:
        if drafts and drafts[0].type is BlockType.HEADING:
            first = drafts[0]
            if not first.text:
                drafts[0] = first.model_copy(update={"text": title, "level": 1})
            elif first.level not in (1, 2):
                drafts[0] = first.model_copy(update={"level": 1})
            return drafts
        return [DraftBlock(type=BlockType.HEADING, text=title, level=1, section_key="introduction")] + drafts

    @staticmethod
    def _fallback_summary(chapter: BlueprintChapter, blocks: list[Block]) -> str:
        types = ", ".join(sorted({b.type.value for b in blocks}))
        return f"{chapter.title}: {chapter.objective} Covered via {types}."


def to_generated_chapter(
    *,
    chapter: BlueprintChapter,
    blocks: list[Block],
    summary: str,
    review: ChapterReview | None,
    revisions: int,
    model: str,
) -> GeneratedChapter:
    return GeneratedChapter(
        chapter_id=chapter.id,
        chapter_number=chapter.order,
        title=chapter.title,
        summary=summary,
        blocks=[block.model_dump(mode="json") for block in blocks],
        review=review.model_dump(mode="json") if review else None,
        revisions=revisions,
        model=model,
        generated_at=utc_now_iso(),
    )
