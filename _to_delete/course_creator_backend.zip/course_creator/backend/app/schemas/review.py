"""One common reviewer for both templates."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

_AI = ConfigDict(extra="ignore")


class ReviewScores(BaseModel):
    model_config = _AI

    accuracy: float = 0.0
    clarity: float = 0.0
    structure: float = 0.0
    audience_fit: float = 0.0
    non_repetition: float = 0.0
    logical_flow: float = 0.0
    template_compliance: float = 0.0
    technical_correctness: float | None = None  # technical courses only
    practical_relevance: float | None = None  # non-technical courses only

    def overall(self) -> float:
        values = [
            v
            for v in self.model_dump().values()
            if isinstance(v, (int, float)) and v is not None
        ]
        return round(sum(values) / len(values), 2) if values else 0.0


class ReviewIssue(BaseModel):
    model_config = _AI

    severity: str = "minor"  # blocker | major | minor
    category: str = ""  # accuracy | clarity | structure | dos | donts | template | code
    block_index: int = -1
    description: str = ""
    suggestion: str = ""


class ChapterReview(BaseModel):
    model_config = ConfigDict(extra="allow")

    approved: bool = True
    scores: ReviewScores = Field(default_factory=ReviewScores)
    issues: list[ReviewIssue] = Field(default_factory=list)
    missing_required_blocks: list[str] = Field(default_factory=list)
    dos_violations: list[str] = Field(default_factory=list)
    donts_violations: list[str] = Field(default_factory=list)
    repetition_notes: list[str] = Field(default_factory=list)
    summary: str = ""
    reviewed_at: str = ""

    def blockers(self) -> list[ReviewIssue]:
        return [i for i in self.issues if i.severity in {"blocker", "major"}]

    def needs_revision(self) -> bool:
        return (
            not self.approved
            or bool(self.blockers())
            or bool(self.missing_required_blocks)
            or bool(self.donts_violations)
        )
