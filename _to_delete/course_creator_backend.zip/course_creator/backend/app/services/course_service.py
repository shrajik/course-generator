"""Pipeline orchestration.

    Course Input -> Planner -> Blueprint -> Research -> Writer -> Reviewer
                 -> Course Document -> Images -> (PDF export)

Generation is synchronous for the POC, but every phase is an awaitable method
operating on persisted artifacts, so moving this behind a queue later means
calling the same methods from a worker instead of from the request handler.
Chapters are independent: chapter 8 can be regenerated on its own.
"""

from __future__ import annotations

import time

from app.agents.planner import PlannerAgent
from app.agents.reviewer import ReviewerAgent
from app.agents.writer import WriterAgent, to_generated_chapter
from app.core.config import Settings, get_settings
from app.core.errors import NotFoundError, ValidationFailedError
from app.core.ids import course_id as new_course_id
from app.core.ids import document_id_for_course, utc_now_iso
from app.core.logging import get_logger
from app.course.document.builder import build_document, reflow_document
from app.course.templates.registry import load_template
from app.schemas.blueprint import BlueprintChapter, CourseBlueprint
from app.schemas.course import (
    ChapterProgress,
    CourseInput,
    CourseRecord,
    GenerateRequest,
    GenerateResponse,
    ImproveTocRequest,
    ImproveTocResponse,
)
from app.schemas.document import CourseDocument
from app.schemas.draft import GeneratedChapter
from app.schemas.review import ChapterReview
from app.services.image_service import ImageService
from app.services.openai_service import AIClient, get_ai_client
from app.services.research_service import ResearchService
from app.services.storage_service import StorageService, get_storage

log = get_logger(__name__)


class CourseService:
    def __init__(
        self,
        ai: AIClient | None = None,
        storage: StorageService | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.storage = storage or get_storage()
        self.ai = ai or get_ai_client()
        self.planner = PlannerAgent(self.ai, self.settings)
        self.writer = WriterAgent(self.ai, self.settings)
        self.reviewer = ReviewerAgent(self.ai, self.settings)
        self.research = ResearchService(self.ai, self.storage, self.settings)
        self.images = ImageService(self.ai, self.storage, self.settings)

    # --- phase 0: create ---------------------------------------------------
    async def create_course(
        self, course_input: CourseInput, *, run_planner: bool = True
    ) -> CourseRecord:
        course_id = new_course_id()
        record = CourseRecord(
            course_id=course_id,
            document_id=document_id_for_course(course_id),
            status="created",
            input=course_input,
            template_id=course_input.template_id,
            created_at=utc_now_iso(),
            updated_at=utc_now_iso(),
        )
        self.storage.save_course(record)
        log.info("Created course %s ('%s')", course_id, course_input.course_title)

        if run_planner:
            try:
                await self.plan_course(record)
            except Exception as exc:  # noqa: BLE001 - keep the course, report the failure
                log.exception("Planning failed for %s", course_id)
                record.last_error = f"planner: {exc}"
                record.warnings.append("Planning failed; blueprint not created.")
                self.storage.save_course(record)
                return record
            record = self.storage.load_course(course_id)
        return record

    # --- phase 1: plan -----------------------------------------------------
    async def plan_course(self, record: CourseRecord) -> CourseBlueprint:
        blueprint = await self.planner.plan(record.input)
        self.storage.save_blueprint(record.course_id, blueprint)
        record.has_blueprint = True
        record.status = "planned"
        record.chapters = [
            ChapterProgress(chapter_id=chapter.id, title=chapter.title)
            for chapter in blueprint.chapters
        ]
        self.storage.save_course(record)
        return blueprint

    async def improve_toc(self, request: ImproveTocRequest) -> ImproveTocResponse:
        return await self.planner.improve_toc(request)

    # --- phase 2+3: generate ----------------------------------------------
    async def generate(self, course_id: str, request: GenerateRequest) -> GenerateResponse:
        started = time.perf_counter()
        record = self.storage.load_course(course_id)
        if not self.storage.has_blueprint(course_id):
            await self.plan_course(record)
            record = self.storage.load_course(course_id)
        blueprint = self.storage.load_blueprint(course_id)
        template = load_template(blueprint.template_id or record.template_id)

        targets = self._select_chapters(blueprint, request)
        if not targets:
            raise ValidationFailedError("No matching chapters to generate")

        generated: list[str] = []
        failed: list[str] = []
        warnings: list[str] = []

        # --- research (concurrent, cached) --------------------------------
        research_map = {}
        if not request.skip_research:
            record.status = "researching"
            self.storage.save_course(record)
            research_map = await self.research.research_chapters(
                course_id=course_id,
                blueprint=blueprint,
                chapters=targets,
                course_input=record.input,
                force=request.force,
            )
            for chapter in targets:
                if chapter.id not in research_map:
                    warnings.append(f"{chapter.id}: research unavailable, wrote without it")

        # --- write + review (sequential: later chapters need earlier summaries)
        record.status = "writing"
        self.storage.save_course(record)
        summaries = self._existing_summaries(course_id, blueprint, targets)

        for chapter in targets:
            previous = [
                (title, summary)
                for order, title, summary in sorted(summaries.values())
                if order < chapter.order
            ]
            try:
                chapter_artifact = await self._generate_chapter(
                    record=record,
                    blueprint=blueprint,
                    chapter=chapter,
                    template=template,
                    research=research_map.get(chapter.id),
                    previous_summaries=previous,
                )
            except Exception as exc:  # noqa: BLE001 - one chapter must not sink the run
                log.exception("Chapter %s failed", chapter.id)
                failed.append(chapter.id)
                self._mark_progress(record, chapter.id, error=str(exc)[:500])
                continue
            generated.append(chapter.id)
            summaries[chapter.id] = (
                chapter.order,
                chapter.title,
                chapter_artifact.summary,
            )

        # --- assemble + illustrate ---------------------------------------
        pages = 0
        images = 0
        if request.build_document:
            record.status = "assembling"
            self.storage.save_course(record)
            document = self.build_course_document(course_id)
            generate_images = (
                self.settings.enable_image_generation
                if request.generate_images is None
                else request.generate_images
            )
            if generate_images:
                record.status = "illustrating"
                self.storage.save_course(record)
                images = await self.images.generate_missing(
                    document=document, template=template, force=request.force
                )
                if images:
                    # Now that the real image dimensions are known, re-paginate.
                    reflow_document(document, template)
                self.storage.save_document(document)
            pages = len(document.pages)
            record.has_document = True

        record.status = "failed" if failed and not generated else "ready"
        record.last_error = f"chapters failed: {', '.join(failed)}" if failed else None
        record.warnings = warnings
        self.storage.save_course(record)

        return GenerateResponse(
            course_id=course_id,
            document_id=record.document_id,
            status=record.status,
            chapters_generated=generated,
            chapters_failed=failed,
            images_generated=images,
            pages=pages,
            warnings=warnings,
            duration_seconds=round(time.perf_counter() - started, 2),
        )

    async def _generate_chapter(
        self,
        *,
        record: CourseRecord,
        blueprint: CourseBlueprint,
        chapter: BlueprintChapter,
        template,
        research,
        previous_summaries: list[tuple[str, str]],
    ) -> GeneratedChapter:
        blocks, summary = await self.writer.write_chapter(
            blueprint=blueprint,
            chapter=chapter,
            template=template,
            course_input=record.input,
            research=research,
            previous_summaries=previous_summaries,
        )
        self._mark_progress(record, chapter.id, researched=research is not None, written=True)

        review: ChapterReview | None = None
        revisions = 0
        try:
            review = await self.reviewer.review_chapter(
                blueprint=blueprint,
                chapter=chapter,
                template=template,
                course_input=record.input,
                blocks=blocks,
                previous_summaries=previous_summaries,
            )
            while review.needs_revision() and revisions < self.settings.max_review_revisions:
                revisions += 1
                log.info("Revising %s (pass %s)", chapter.id, revisions)
                blocks, summary = await self.writer.revise_chapter(
                    blueprint=blueprint,
                    chapter=chapter,
                    template=template,
                    course_input=record.input,
                    research=research,
                    previous_summaries=previous_summaries,
                    review=review,
                )
                review = await self.reviewer.review_chapter(
                    blueprint=blueprint,
                    chapter=chapter,
                    template=template,
                    course_input=record.input,
                    blocks=blocks,
                    previous_summaries=previous_summaries,
                )
        except Exception as exc:  # noqa: BLE001 - review is advisory, not fatal
            log.warning("Review failed for %s: %s", chapter.id, exc)

        artifact = to_generated_chapter(
            chapter=chapter,
            blocks=blocks,
            summary=summary,
            review=review,
            revisions=revisions,
            model="mock" if self.ai.is_mock else self.settings.writer_model,
        )
        self.storage.save_chapter(record.course_id, artifact)
        self._mark_progress(
            record,
            chapter.id,
            reviewed=review is not None,
            review_score=review.scores.overall() if review else None,
        )
        return artifact

    # --- document ---------------------------------------------------------
    def build_course_document(self, course_id: str) -> CourseDocument:
        blueprint = self.storage.load_blueprint(course_id)
        template = load_template(blueprint.template_id)
        chapters = self.storage.load_all_chapters(course_id)
        if not chapters:
            raise NotFoundError(
                f"Course '{course_id}' has no generated chapters yet - run generation first"
            )
        existing = self.storage.load_document(course_id) if self.storage.has_document(course_id) else None
        document = build_document(
            course_id=course_id,
            blueprint=blueprint,
            template=template,
            chapters=chapters,
            existing=existing,
        )
        # Carry generated image paths across rebuilds so we don't pay twice.
        if existing is not None:
            self._carry_over_assets(existing, document)
        self.storage.save_document(document)
        return document

    @staticmethod
    def _carry_over_assets(old: CourseDocument, new: CourseDocument) -> None:
        from app.schemas.blocks import BlockType, merge_content

        by_prompt = {}
        for _, block in old.iter_blocks():
            if block.type is BlockType.IMAGE and block.content.get("path"):
                key = (block.content.get("purpose", ""), block.content.get("caption", ""))
                by_prompt[key] = block.content
        for _, block in new.iter_blocks():
            if block.type is not BlockType.IMAGE or block.content.get("path"):
                continue
            key = (block.content.get("purpose", ""), block.content.get("caption", ""))
            previous = by_prompt.get(key)
            if previous:
                block.content = merge_content(
                    block.type,
                    block.content,
                    {
                        "path": previous.get("path"),
                        "asset_id": previous.get("asset_id"),
                        "generated": True,
                    },
                )

    # --- helpers ----------------------------------------------------------
    @staticmethod
    def _select_chapters(
        blueprint: CourseBlueprint, request: GenerateRequest
    ) -> list[BlueprintChapter]:
        if not request.chapter_ids:
            return list(blueprint.chapters)
        wanted = set(request.chapter_ids)
        unknown = wanted - set(blueprint.chapter_ids())
        if unknown:
            raise ValidationFailedError(
                f"Unknown chapter ids: {', '.join(sorted(unknown))}",
                details={"available": blueprint.chapter_ids()},
            )
        return [chapter for chapter in blueprint.chapters if chapter.id in wanted]

    def _existing_summaries(
        self,
        course_id: str,
        blueprint: CourseBlueprint,
        targets: list[BlueprintChapter],
    ) -> dict[str, tuple[int, str, str]]:
        """Summaries of chapters already on disk, for continuity context."""
        target_ids = {chapter.id for chapter in targets}
        summaries: dict[str, tuple[int, str, str]] = {}
        for chapter in self.storage.load_all_chapters(course_id):
            if chapter.chapter_id in target_ids:
                continue  # about to be regenerated
            summaries[chapter.chapter_id] = (
                chapter.chapter_number,
                chapter.title,
                chapter.summary,
            )
        return summaries

    def _mark_progress(self, record: CourseRecord, chapter_id: str, **fields) -> None:
        for progress in record.chapters:
            if progress.chapter_id == chapter_id:
                for key, value in fields.items():
                    if value is not None:
                        setattr(progress, key, value)
                break
        self.storage.save_course(record)


_service: CourseService | None = None


def get_course_service() -> CourseService:
    global _service
    if _service is None:
        _service = CourseService()
    return _service


def reset_course_service() -> None:
    global _service
    _service = None
