"""OpenAI access layer.

Every AI call in the application goes through `AIClient`. There are two
implementations:

* `OpenAIClient` - the real thing (structured output, web/deep research, images).
* `MockAIClient` - deterministic offline responses (`app/services/mock_ai.py`).

The rest of the code never imports `openai` directly, which is what makes the
pipeline testable without an API key and swappable later.
"""

from __future__ import annotations

import abc
import asyncio
import base64
import json
import random
import re
from typing import Any, TypeVar

from pydantic import BaseModel, ValidationError

from app.core.config import Settings, get_settings
from app.core.errors import AIServiceError
from app.core.logging import get_logger

log = get_logger(__name__)

T = TypeVar("T", bound=BaseModel)

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


class ResearchResult(BaseModel):
    text: str = ""
    citations: list[dict[str, str]] = []
    model: str = ""
    mode: str = "fast"


class AIClient(abc.ABC):
    """Interface used by every agent."""

    is_mock: bool = False

    @abc.abstractmethod
    async def structured(
        self,
        *,
        schema: type[T],
        system: str,
        user: str,
        model: str | None = None,
        purpose: str = "",
        max_output_tokens: int | None = None,
    ) -> T:
        """Return an instance of `schema` produced by the model."""

    @abc.abstractmethod
    async def research(
        self, *, prompt: str, deep: bool = False, system: str = ""
    ) -> ResearchResult:
        """Gather grounded notes, using web search where the model supports it."""

    @abc.abstractmethod
    async def image(self, *, prompt: str, size: str | None = None) -> bytes:
        """Return PNG bytes."""


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def strip_fences(text: str) -> str:
    return _FENCE_RE.sub("", text or "").strip()


def extract_json_object(text: str) -> dict[str, Any]:
    """Tolerant JSON extraction - models occasionally wrap or prefix output."""
    cleaned = strip_fences(text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(cleaned[start : end + 1])
        except json.JSONDecodeError:
            pass
    raise AIServiceError(
        "Model did not return valid JSON", details={"preview": cleaned[:400]}
    )


def schema_hint(schema: type[BaseModel]) -> str:
    return json.dumps(schema.model_json_schema(), ensure_ascii=False)


# ---------------------------------------------------------------------------
# real client
# ---------------------------------------------------------------------------


class OpenAIClient(AIClient):
    is_mock = False

    _RETRIES = 3

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self._client = None

    # --- plumbing ---------------------------------------------------------
    @property
    def client(self):
        if self._client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError as exc:  # pragma: no cover
                raise AIServiceError("The `openai` package is not installed") from exc
            if not self.settings.openai_api_key:
                raise AIServiceError("OPENAI_API_KEY is not configured")
            kwargs: dict[str, Any] = {
                "api_key": self.settings.openai_api_key,
                "timeout": self.settings.request_timeout,
                "max_retries": 0,  # we handle retries ourselves
            }
            if self.settings.openai_base_url:
                kwargs["base_url"] = self.settings.openai_base_url
            self._client = AsyncOpenAI(**kwargs)
        return self._client

    async def _with_retries(self, label: str, factory):
        last_error: Exception | None = None
        for attempt in range(1, self._RETRIES + 1):
            try:
                return await factory()
            except Exception as exc:  # noqa: BLE001 - normalised below
                last_error = exc
                if not self._is_retryable(exc) or attempt == self._RETRIES:
                    break
                delay = min(2 ** attempt + random.random(), 20)
                log.warning(
                    "%s failed (attempt %s/%s): %s - retrying in %.1fs",
                    label,
                    attempt,
                    self._RETRIES,
                    exc,
                    delay,
                )
                await asyncio.sleep(delay)
        raise AIServiceError(f"{label} failed: {last_error}") from last_error

    @staticmethod
    def _is_retryable(exc: Exception) -> bool:
        status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
        if isinstance(status, int) and (status == 429 or status >= 500):
            return True
        name = type(exc).__name__
        return name in {
            "APIConnectionError",
            "APITimeoutError",
            "RateLimitError",
            "InternalServerError",
            "APIConnectionTimeoutError",
        }

    # --- structured output -------------------------------------------------
    async def structured(
        self,
        *,
        schema: type[T],
        system: str,
        user: str,
        model: str | None = None,
        purpose: str = "",
        max_output_tokens: int | None = None,
    ) -> T:
        model_name = model or self.settings.writer_model
        label = f"structured[{purpose or schema.__name__}]"
        json_schema = schema.model_json_schema()

        async def call(response_format: dict[str, Any], system_prompt: str) -> str:
            kwargs: dict[str, Any] = {
                "model": model_name,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user},
                ],
                "response_format": response_format,
            }
            if max_output_tokens:
                kwargs["max_completion_tokens"] = max_output_tokens
            completion = await self.client.chat.completions.create(**kwargs)
            return completion.choices[0].message.content or ""

        schema_format = {
            "type": "json_schema",
            "json_schema": {
                "name": schema.__name__.lower(),
                "schema": json_schema,
                "strict": False,
            },
        }
        json_format = {"type": "json_object"}
        system_with_schema = (
            f"{system}\n\nReturn a single JSON object that conforms to this JSON Schema:\n"
            f"{json.dumps(json_schema, ensure_ascii=False)}"
        )

        raw: str
        try:
            raw = await self._with_retries(label, lambda: call(schema_format, system))
        except AIServiceError as exc:
            log.warning("%s: json_schema mode unavailable (%s) - falling back", label, exc)
            raw = await self._with_retries(
                label, lambda: call(json_format, system_with_schema)
            )

        try:
            return schema.model_validate(extract_json_object(raw))
        except (ValidationError, AIServiceError) as exc:
            log.warning("%s: invalid payload, attempting one repair pass: %s", label, exc)
            repair_system = (
                f"{system_with_schema}\n\nYour previous answer was rejected with these "
                f"validation errors:\n{exc}\nReturn corrected JSON only."
            )
            repaired = await self._with_retries(
                label + ":repair", lambda: call(json_format, repair_system)
            )
            try:
                return schema.model_validate(extract_json_object(repaired))
            except (ValidationError, AIServiceError) as final_exc:
                raise AIServiceError(
                    f"{label}: model output failed validation twice: {final_exc}"
                ) from final_exc

    # --- research ----------------------------------------------------------
    async def research(
        self, *, prompt: str, deep: bool = False, system: str = ""
    ) -> ResearchResult:
        model_name = (
            self.settings.deep_research_model if deep else self.settings.research_model
        )
        tool = {"type": "web_search_preview"} if deep else {"type": "web_search"}
        instructions = system or "You are a meticulous research assistant."

        async def call(tools: list[dict[str, Any]] | None):
            kwargs: dict[str, Any] = {
                "model": model_name,
                "input": prompt,
                "instructions": instructions,
            }
            if tools:
                kwargs["tools"] = tools
            return await self.client.responses.create(**kwargs)

        label = f"research[{'deep' if deep else 'fast'}]"
        try:
            response = await self._with_retries(label, lambda: call([tool]))
        except AIServiceError as exc:
            log.warning("%s: web search tool unavailable (%s) - retrying ungrounded", label, exc)
            response = await self._with_retries(label + ":no-tools", lambda: call(None))

        return ResearchResult(
            text=self._response_text(response),
            citations=self._citations(response),
            model=model_name,
            mode="deep" if deep else "fast",
        )

    @staticmethod
    def _response_text(response: Any) -> str:
        text = getattr(response, "output_text", None)
        if text:
            return text
        chunks: list[str] = []
        for item in getattr(response, "output", []) or []:
            for part in getattr(item, "content", []) or []:
                value = getattr(part, "text", None)
                if isinstance(value, str):
                    chunks.append(value)
        return "\n".join(chunks)

    @staticmethod
    def _citations(response: Any) -> list[dict[str, str]]:
        found: list[dict[str, str]] = []
        seen: set[str] = set()
        for item in getattr(response, "output", []) or []:
            for part in getattr(item, "content", []) or []:
                for annotation in getattr(part, "annotations", []) or []:
                    url = getattr(annotation, "url", None)
                    if url and url not in seen:
                        seen.add(url)
                        found.append(
                            {"title": getattr(annotation, "title", "") or url, "url": url}
                        )
        return found

    # --- images ------------------------------------------------------------
    async def image(self, *, prompt: str, size: str | None = None) -> bytes:
        async def call():
            return await self.client.images.generate(
                model=self.settings.image_model,
                prompt=prompt,
                size=size or self.settings.image_size,
                n=1,
            )

        response = await self._with_retries("image", call)
        item = response.data[0]
        b64 = getattr(item, "b64_json", None)
        if b64:
            return base64.b64decode(b64)
        url = getattr(item, "url", None)
        if url:
            import httpx

            async with httpx.AsyncClient(timeout=120) as http:
                fetched = await http.get(url)
                fetched.raise_for_status()
                return fetched.content
        raise AIServiceError("Image response contained neither b64_json nor url")


# ---------------------------------------------------------------------------
# factory
# ---------------------------------------------------------------------------

_client: AIClient | None = None


def get_ai_client() -> AIClient:
    global _client
    if _client is None:
        settings = get_settings()
        if settings.use_mock_ai:
            from app.services.mock_ai import MockAIClient

            reason = "MOCK_OPENAI=true" if settings.mock_openai else "no OPENAI_API_KEY set"
            log.warning("Using the offline mock AI client (%s).", reason)
            _client = MockAIClient(settings)
        else:
            _client = OpenAIClient(settings)
    return _client


def set_ai_client(client: AIClient | None) -> None:
    """Dependency injection hook for tests."""
    global _client
    _client = client
