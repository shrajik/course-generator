"""Application settings. Everything is environment driven - no secrets in code."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

ResearchMode = Literal["fast", "deep"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
        protected_namespaces=(),
    )

    # --- OpenAI -------------------------------------------------------------
    openai_api_key: str = ""
    openai_base_url: str | None = None

    planner_model: str = "gpt-5"
    writer_model: str = "gpt-5"
    reviewer_model: str = "gpt-5"
    editor_model: str = "gpt-5"
    research_model: str = "gpt-5"
    deep_research_model: str = "o4-mini-deep-research"
    image_model: str = "gpt-image-1"
    image_size: str = "1024x1024"

    # --- Behaviour ----------------------------------------------------------
    research_mode: ResearchMode = "fast"
    mock_openai: bool = False
    enable_image_generation: bool = True
    max_concurrency: int = Field(default=3, ge=1, le=16)
    request_timeout: float = 900.0
    max_review_revisions: int = Field(default=1, ge=0, le=3)

    # --- Storage / misc -----------------------------------------------------
    data_dir: Path = Path("data")
    log_level: str = "INFO"
    app_name: str = "AI Course Creation Platform - Backend POC"
    app_version: str = "0.1.0"

    @property
    def use_mock_ai(self) -> bool:
        """Mock client is used explicitly, or implicitly when no key is configured."""
        return self.mock_openai or not self.openai_api_key.strip()

    @property
    def courses_dir(self) -> Path:
        return self.data_dir / "courses"

    @property
    def index_dir(self) -> Path:
        return self.data_dir / "index"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


def reset_settings_cache() -> None:
    """Used by tests after mutating the environment."""
    get_settings.cache_clear()
