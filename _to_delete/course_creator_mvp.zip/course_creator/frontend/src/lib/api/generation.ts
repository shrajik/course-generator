import { request } from "./client";
import type { GenerateRequest, GenerateResponse } from "@/lib/types/course";

/**
 * Generation is synchronous in the backend POC: this promise resolves only when
 * the whole course is finished. The Generating screen therefore fires this once
 * and polls GET /api/courses/{id} for the real per-chapter progress the backend
 * persists while it works.
 */
export function generateCourse(
  courseId: string,
  payload: GenerateRequest = {},
): Promise<GenerateResponse> {
  return request<GenerateResponse>(`/api/courses/${courseId}/generate`, {
    method: "POST",
    body: payload,
  });
}
