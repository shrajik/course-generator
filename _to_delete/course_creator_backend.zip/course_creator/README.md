# AI Course Creation Platform — Backend POC

Turns `TOC + audience + do's/don'ts + template` into `research + course content + images + editable Course JSON + PDF`.

Backend only. No frontend, no database, no queue, no object storage — those come in the next phase.

```
Course Input → Planner → Blueprint → Deep Research → Research Artifacts
            → Chapter Writer → Chapter Reviewer → Course Document JSON
            → Image Generation → PDF Renderer → Final PDF
```

**The Course Document JSON is the source of truth. The PDF is only an export.**

---

## Quick start

```bash
cp .env.example .env      # then put your OPENAI_API_KEY in it
docker compose up --build
```

Open <http://localhost:8000/docs>.

No Python installation needed on the host. Generated artifacts land in `backend/data/` on your machine
(bind-mounted), so you can inspect every blueprint, research file, chapter, document and PDF directly.

### Running it without an API key

If `OPENAI_API_KEY` is empty (or `MOCK_OPENAI=true`), the backend uses a built-in **offline mock client**
that returns schema-valid placeholder content. The entire pipeline — planning, research, writing, review,
document assembly, image generation, patch editing, PDF export — runs end to end with no network calls.
This is what the test suite uses, and it's the fastest way to see the shape of the output.

### Local development without Docker

```bash
cd backend
pip install -r requirements.txt
python -m playwright install chromium
uvicorn app.main:app --reload
```

---

## Try the whole flow

```bash
# 1. Ask for TOC improvements (advisory — nothing is saved)
curl -s localhost:8000/api/courses/improve-toc -H 'content-type: application/json' -d '{
  "course_title": "Introduction to RAG",
  "toc": ["What is RAG", "Chunking and Embeddings", "Evaluating a RAG System"],
  "audience": "Backend engineers new to LLMs",
  "template": "technical"
}' | jq

# 2. Create the course (runs the planner → blueprint)
COURSE=$(curl -s localhost:8000/api/courses -H 'content-type: application/json' -d '{
  "course_title": "Introduction to RAG",
  "toc": [
    {"title": "What is RAG", "sections": ["Motivation", "Architecture"]},
    {"title": "Chunking and Embeddings"},
    {"title": "Evaluating a RAG System"}
  ],
  "target_audience": "Backend engineers new to LLMs",
  "dos": ["Use concrete, runnable examples", "Define jargon on first use"],
  "donts": ["No marketing language", "Do not cite unverified benchmarks"],
  "template": "technical"
}')
CID=$(echo "$COURSE" | jq -r .course_id)
DID=$(echo "$COURSE" | jq -r .document_id)

# 3. Research + write + review + assemble + illustrate
curl -s -X POST localhost:8000/api/courses/$CID/generate -H 'content-type: application/json' -d '{}' | jq

# 4. Inspect the course document
curl -s localhost:8000/api/courses/$CID/document | jq '.pages | length'

# 5. Regenerate a single chapter only
curl -s -X POST localhost:8000/api/courses/$CID/generate -H 'content-type: application/json' \
  -d '{"chapter_ids": ["chapter_2"], "force": true}' | jq

# 6. AI-edit one block (returns a PATCH, not a document)
BLOCK=$(curl -s localhost:8000/api/courses/$CID/document \
  | jq -r '[.pages[].blocks[] | select(.type=="paragraph")][0].id')
curl -s -X POST localhost:8000/api/documents/$DID/ai-edit -H 'content-type: application/json' \
  -d "{\"selected_block_ids\": [\"$BLOCK\"], \"instruction\": \"Make this easier to understand\"}" | jq

# 7. Export the PDF
curl -s -X POST "localhost:8000/api/documents/$DID/export/pdf" -o course.pdf
```

There is also `GET /api/documents/{document_id}/preview`, which serves the exact HTML the PDF is
rendered from — much faster than re-exporting while you iterate on styling.

---

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/courses` | Create a course; runs the planner (`"run_planner": false` to skip) |
| POST | `/api/courses/improve-toc` | Propose a better TOC + changes + reasoning (never applied automatically) |
| POST | `/api/courses/{course_id}/generate` | Research → write → review → assemble → illustrate |
| GET | `/api/courses/{course_id}` | Status, progress and which artifacts exist |
| GET | `/api/courses/{course_id}/document` | The Course Document JSON |
| POST | `/api/documents/{document_id}/ai-edit` | Instruction on selected blocks → validated patch |
| POST | `/api/documents/{document_id}/export/pdf` | Render the current document to PDF |

Supporting endpoints: `GET /health`, `GET /api/courses`, `GET /api/courses/templates`,
`GET /api/courses/{id}/blueprint`, `GET /api/courses/{id}/chapters/{chapter_id}`,
`GET /api/courses/{id}/chapters/{chapter_id}/research`, `GET /api/courses/{id}/template`,
`GET /api/documents/{id}`, `GET /api/documents/{id}/preview`, `GET /api/documents/{id}/assets/{name}`.

---

## The two templates

There is **one** AI pipeline (planner → research → writer → reviewer → editor). The template only changes
content structure and default presentation rules, and is passed to the agents as *data*:
`backend/app/course/templates/technical_v1.json` and `non_technical_v1.json`.

| | Technical | Non-Technical |
| --- | --- | --- |
| For | programming, AI/ML, cloud, DevOps, security | business, marketing, leadership, sales, finance |
| Chapter shape | Introduction · Objectives · Concept · How It Works · Visual · Technical Example · Code · Step-by-Step · Common Mistakes · Best Practices · Exercise · Challenge · Quiz · Summary | Introduction · Objectives · Story · Core Concept · Real-World Example · Case Study · Framework · Practical Application · Common Mistakes · Pro Tips · Reflection · Exercise · Quiz · Summary |
| Reviewer emphasis | technical correctness, code quality | clarity, practical relevance |

Editing a template's JSON changes structure and styling with no code changes.

---

## Course Document model

Each block keeps **content**, **style** and **layout** separate, so the future editor can mutate any of
the three independently:

```json
{
  "id": "block_1f2e3d4c5b6a",
  "type": "heading",
  "content": { "text": "Understanding RAG", "level": 2 },
  "style":   { "font_size": 26, "font_weight": 700, "color": "#0f172a" },
  "layout":  { "x": 64, "y": 100, "width": 666, "height": 46, "z_index": 0 },
  "meta":    { "chapter_id": "chapter_1", "section_key": "concept", "origin": "generated" }
}
```

Block types: `heading, paragraph, image, quote, callout, code, table, quiz, exercise, case_study, story,
tip, warning, summary, divider` plus `learning_objectives, challenge, reflection`.

The system is extensible: add an enum member in `app/schemas/blocks.py`, a content model, one registry
entry, and one branch in `app/render/templates/course.html.j2`. Nothing else changes.

`layout` coordinates are produced by a deterministic layout engine (`app/course/document/layout.py`) that
estimates block heights and flows blocks into A4 pages (794×1123 px @ 96 DPI), splitting long paragraphs,
code and lists across page boundaries and never orphaning a heading.

---

## AI editing

`POST /api/documents/{document_id}/ai-edit`

```json
{ "selected_block_ids": ["block_102"], "instruction": "Make this easier to understand" }
```

The model must return operations, never a document:

```json
{ "operations": [ { "type": "update_block", "block_id": "block_102",
                    "content": { "text": "Simplified explanation..." } } ] }
```

Supported: `update_block`, `delete_block`, `insert_block`, `replace_block`, `replace_image`,
`update_style`. Every patch is Pydantic-validated, then sanitised — operations targeting blocks outside
the selection, unknown block ids, or non-presentation style keys are dropped and reported in
`rejected_operations`. Valid operations still apply if one is bad. After applying, the document is
re-paginated, its `version` is bumped, and it is written back to disk.

Pass `"apply": false` to preview the patch without changing anything.

---

## Storage layout

```
backend/data/courses/{course_id}/
  course.json                 status, input, per-chapter progress
  blueprint.json              planner output + critique
  research/chapter_01.json    one research artifact per chapter
  chapters/chapter_01.json    generated blocks + summary + review
  document.json               the source of truth
  assets/image_001.png        generated images
  exports/course.pdf          export (course.html is written alongside it)
```

Chapters are independent: if chapter 8 fails, regenerate only chapter 8 with
`{"chapter_ids": ["chapter_8"], "force": true}`. Research is cached per chapter and reused unless
`force` is set.

---

## Configuration

See `.env.example`. The ones that matter:

| Variable | Default | Notes |
| --- | --- | --- |
| `OPENAI_API_KEY` | *(empty)* | Empty ⇒ offline mock client |
| `RESEARCH_MODE` | `fast` | `fast` = model + `web_search` per chapter; `deep` = Deep Research API (much slower and pricier) |
| `MOCK_OPENAI` | `false` | Force the offline client even with a key |
| `ENABLE_IMAGE_GENERATION` | `true` | Turn off to skip image cost |
| `MAX_CONCURRENCY` | `3` | Concurrent chapter research / image jobs |
| `MAX_REVIEW_REVISIONS` | `1` | Rewrite passes when the reviewer finds blockers |
| `PLANNER_MODEL` etc. | `gpt-5` | Per-agent model overrides |

---

## Project structure

```
backend/app/
  api/          courses.py, documents.py, health.py      — HTTP only
  agents/       planner, research, writer, reviewer, editor, prompts
  course/
    templates/  technical_v1.json, non_technical_v1.json, registry.py
    blocks/     normalizer.py   (writer draft → validated blocks)
    document/   builder.py, layout.py, patcher.py
  render/       html_renderer.py + templates/course.html.j2
  schemas/      blocks, course, blueprint, research, draft, review, document, patch, template
  services/     openai_service, mock_ai, research_service, image_service,
                pdf_service, storage_service, course_service, document_service
  core/         config, errors, ids, logging
```

AI logic, PDF logic and document models are kept in separate layers. `openai_service.AIClient` is the
only place that talks to OpenAI, and it's an interface with two implementations (real + mock), which is
what makes the pipeline testable offline.

---

## Tests

```bash
cd backend && python -m pytest        # or: docker compose run --rm backend pytest
```

99 tests, no API key required: Pydantic schemas, template validation, layout/pagination/splitting,
patch validation and application, course creation, TOC improvement, document assembly, image generation,
HTML rendering (including escaping), PDF export, and two full end-to-end runs — one per template —
that walk create → improve-toc → blueprint → research → generate → review → document → image →
AI edit → PDF and assert on the real PDF bytes.

The Playwright-dependent tests skip automatically if Chromium isn't available.

---

## Deliberate POC limitations

- Generation is **synchronous**. Every phase is an `await`-able method operating on persisted artifacts,
  so putting this behind a worker later means calling the same methods from a queue consumer — no rewrite
  of the AI services.
- No auth, no rate limiting, CORS is wide open. Do not deploy as-is.
- Layout heights are *estimated*, not measured by a text-shaping engine. Estimates deliberately err high;
  boxes use `min-height` so content grows rather than clipping.
- Concurrent writes to the same course are not locked.

## Next step

Build the Next.js frontend and Canva-like editor against these endpoints, then add PostgreSQL, Redis,
background workers and object storage.
